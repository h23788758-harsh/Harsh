# Harsh AI — Android se setup

Is project mein aapke original Harsh AI HTML ka dark/blue design, home screen, chat view, chips, clear button aur install prompt preserve kiye gaye hain. AI chat ko secure Node.js backend ke through OpenAI Responses API se connect kiya gaya hai.

## Features
- Hindi/Hinglish mein AI answers
- Last 20 chat messages browser ke localStorage mein save; reload par restore
- Clear button se local chat history delete
- API key server environment variable mein, HTML mein nahi
- Basic rate limit and request validation

## Important
- API key ChatGPT login se automatically nahi milti; API platform par separately create karni hoti hai and API usage may be billed separately.
- Sirf HTML file ko Android par kholne se backend nahi chalega. Is project ko Node.js server hosting par deploy karna hoga; mobile se hosting dashboard use kar sakte hain.
- Browser localStorage memory sirf us browser/device tak rehti hai. Yeh cross-device account memory nahi hai.
- `store: false` API response storage ko disable karta hai; app history browser ke localStorage mein hai. Browser data clear karne par history mit sakti hai.

## Deploy (Android phone se)
1. ZIP extract karke Git repository mein upload karo, ya hosting provider ke Node.js project import feature mein ZIP/repository do.
2. Runtime Node.js 20+ set karo.
3. Build/install command: `npm install`
4. Start command: `npm start`
5. Hosting ke Environment Variables/Secrets mein `OPENAI_API_KEY` set karo. `OPENAI_MODEL` ko `gpt-5-mini` rehne do ya apne account mein available model set karo.
6. Deploy karo, phir hosted URL kholo. `/api/health` par `{"ok":true}` aana chahiye.
7. Main hosted URL par Harsh AI chat try karo.

## Local testing (computer or supported mobile terminal)
1. `.env.example` ko `.env` naam se copy karo.
2. `.env` mein apni API key paste karo — key kisi ko send mat karna.
3. `npm install`
4. `npm start`
5. Browser mein `http://localhost:3000` kholo.

## Security notes
- `.env` ko public repository mein kabhi commit mat karo.
- API key ko HTML, JavaScript frontend, APK assets ya screenshot mein mat daalo.
- Production app ke liye authentication/user limits bhi add karo; rate limiting per IP akela full abuse protection nahi hai.
